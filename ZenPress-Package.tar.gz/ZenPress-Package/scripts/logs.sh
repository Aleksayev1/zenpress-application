#!/bin/bash

echo "📋 Logs do ZenPress:"
docker-compose logs -f