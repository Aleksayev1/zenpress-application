#!/bin/bash

echo "🚀 Iniciando ZenPress..."
docker-compose up -d
echo "✅ ZenPress iniciado com sucesso!"
echo "🌐 Acesse: http://localhost:3000"