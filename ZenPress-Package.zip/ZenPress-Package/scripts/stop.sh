#!/bin/bash

echo "🛑 Parando ZenPress..."
docker-compose down
echo "✅ ZenPress parado com sucesso!"